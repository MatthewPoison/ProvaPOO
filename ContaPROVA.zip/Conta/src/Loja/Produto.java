package Loja;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
class Produto {
    private int codigo;
    private String nome;
    private String descricao;
    private double precoCompra;
    private double precoVenda;
    private double desconto;
    private String fabricante;
    private Fornecedor fornecedor;

    public Produto(int codigo, String nome, String descricao, double precoCompra, double precoVenda, double desconto, String fabricante, Fornecedor fornecedor) {
        this.codigo = codigo;
        this.nome = nome;
        this.descricao = descricao;
        this.precoCompra = precoCompra;
        this.precoVenda = precoVenda;
        this.desconto = desconto;
        this.fabricante = fabricante;
        this.fornecedor = fornecedor;
    }

    // Getters e Setters
    public int getCodigo() {
        return codigo;
    }

    public String getNome() {
        return nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public double getPrecoCompra() {
        return precoCompra;
    }

    public double getPrecoVenda() {
        return precoVenda;
    }

    public double getDesconto() {
        return desconto;
    }

    public String getFabricante() {
        return fabricante;
    }

    public Fornecedor getFornecedor() {
        return fornecedor;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Produto produto = (Produto) o;
        return codigo == produto.codigo && Double.compare(produto.precoCompra, precoCompra) == 0 && Double.compare(produto.precoVenda, precoVenda) == 0 && Double.compare(produto.desconto, desconto) == 0 && Objects.equals(nome, produto.nome) && Objects.equals(descricao, produto.descricao) && Objects.equals(fabricante, produto.fabricante) && Objects.equals(fornecedor, produto.fornecedor);
    }

    @Override
    public int hashCode() {
        return Objects.hash(codigo, nome, descricao, precoCompra, precoVenda, desconto, fabricante, fornecedor);
    }

    @Override
    public String toString() {
        return "Produto{" +
                "codigo=" + codigo +
                ", nome='" + nome + '\'' +
                ", descricao='" + descricao + '\'' +
                ", precoCompra=" + precoCompra +
                ", precoVenda=" + precoVenda +
                ", desconto=" + desconto +
                ", fabricante='" + fabricante + '\'' +
                ", fornecedor=" + fornecedor.getNome() +
                '}';
    }

}



