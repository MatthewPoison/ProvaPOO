package Loja;
public class Main {
    public static void main(String[] args) {
        Fornecedor p1 = new Fornecedor();
        Produto p2 = new Produto();

    }
}
